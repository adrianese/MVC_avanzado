<?php

namespace Model;

class Profesores extends Base {
    // Base DE DATOS
    protected static $tabla = 'profesores';
    protected static $columnasDB = ['id', 'nombre', 'apellido', 'curso'];

    public $id;
    public $nombre;
    public $apellido;
    public $curso;

    public function __construct($args = []) {
        
        $this->id = $args['id'] ?? null;
        $this->nombre = $args['nombre'] ?? '';
        $this->apellido = $args['apellido'] ?? '';
        $this->curso = $args['curso'] ?? '';
    }


}