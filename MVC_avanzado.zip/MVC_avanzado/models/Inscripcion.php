<?php

namespace Model;

class Inscripcion extends Base {

       // Base DE DATOS
       protected static $tabla = 'inscripcion';
       protected static $columnasDB = ['id', 'nombre', 'apellido', 'correo', 'edad', 'info', 'fecha', 'fk_curso'];
   
   
       public $id;
       public $nombre;
       public $apellido;
       public $correo;
       public $edad;
       public $info;
       public $fecha;
       public $fk_curso;
     
   
       public function __construct($args = [])
       {
           $this->id = $args['id'] ?? null;
           $this->nombre = $args['nombre'] ?? '';
           $this->apellido = $args['apellido'] ?? '';
           $this->correo = $args['correo'] ?? '';
           $this->edad = $args['edad'] ?? '';
           $this->info = $args['info'] ?? '';          
           $this->fecha = date('Y-m-d');
           $this->fk_curso = $args['fk_curso'] ?? '';
       }
   
       public function validar() {
   
           if(!$this->nombre) {
               self::$errores[] = "Debes añadir un nombre";
           }
   
           if(!$this->apellido) {
               self::$errores[] = 'El Apellido es Obligatorio';
           }
   
           if(!$this->correo) {
            self::$errores[] = 'El correo es obligatorio';
            }
            if(!$this->edad) {
            self::$errores[] = 'Ingresa tu edad';
             }
           if(!$this->info) {
               self::$errores[] = 'Elige tu opción';
           }
           
        
           return self::$errores;
       }
}