<?php

namespace Model;

class Cursos extends Base {


       // Base DE DATOS
       protected static $tabla = 'cursos';
       protected static $columnasDB = ['id', 'nombre', 'descripcion', 'precio', 'imagen', 'cupo', 'fk_profesor'];
   
   
       public $id;
       public $nombre;
       public $descripcion;
       public $precio;
       public $imagen;
       public $cupo;
       public $fk_profesor;
     
   
       public function __construct($args = [])
       {
           $this->id = $args['id'] ?? null;
           $this->nombre = $args['nombre'] ?? '';
           $this->descripcion = $args['descripcion'] ?? '';
           $this->precio = $args['precio'] ?? '';
           $this->imagen = $args['imagen'] ?? '';
         
           $this->cupo = $args['cupo'] ?? '';
           $this->fk_profesor = $args['fk_profesor'] ?? '';
      
       }
   
       public function validar() {
   
           if(!$this->nombre) {
               self::$errores[] = "Debes añadir un titulo";
           }
   
           if(!$this->precio) {
               self::$errores[] = 'El Precio es Obligatorio';
           }
   
           if( strlen( $this->descripcion ) < 50 ) {
               self::$errores[] = 'La descripción es obligatoria y debe tener al menos 50 caracteres';
           }
   
           if(!$this->cupo) {
               self::$errores[] = 'El Número de cupo es obligatorio';
           }
           
           if(!$this->fk_profesor) {
               self::$errores[] = 'El nombre del profesor es obligatorio';
           }
   
           if(!$this->imagen ) {
               self::$errores[] = 'La Imagen es Obligatoria';
           }
   
           return self::$errores;
       }


}