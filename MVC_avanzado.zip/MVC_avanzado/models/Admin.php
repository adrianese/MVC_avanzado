<?php

namespace Model;

class Admin extends Base {
    // Base DE DATOS
    protected static $tabla = 'administracion';
    protected static $columnasDB = ['id', 'usuario', 'clave'];

    public $id;
    public $usuario;
    public $clave;

    public function __construct($args = [])
    {
        $this->id = $args['id'] ?? null;
        $this->usuario = $args['usuario'] ?? '';
        $this->clave = $args['clave'] ?? '';
    }

    public function validar() {
        if(!$this->usuario) {
            self::$errores[] = "El usuario es obligatorio";
        }
        if(!$this->clave) {
            self::$errores[] = "El Password es obligatorio";
        }
        return self::$errores;
    }

    public function existeUsuario() {
        // Revisar si el usuario existe.
        $query = "SELECT * FROM administracion WHERE usuario = '" . $this->usuario . "' LIMIT 1";
        $resultado = self::$db->query($query);
      
        if(!$resultado->num_rows) {
            self::$errores[] = 'El Usuario No Existe';
            return;
         
        } 
        return $resultado;
    }

    public function comprobarClave($resultado) {

        $usuario = $resultado->fetch_object() ;
         $autenticado = password_verify($this->clave, $usuario->clave);
   
        if (!$autenticado) {
            self::$errores[] = 'El Password es Incorrecto';
           
        }
        return $autenticado;
    }

    public function autenticar(){
            session_start();
            //Arreglo de session
            $_SESSION['usuario'] = $this->usuario;
            $_SESSION['login'] = true;
            $_SESSION['welcome'] = true;
            header('Location: /admin');
    }

}
