<?php

namespace Controllers;

use MVC\Router;
use Model\Inscripcion;
use Model\Cursos;


class InscripcionController {

        public static function index(Router $router){

            $alumnos = Inscripcion::all(); //metodo para traer todos los alumnos
            // $resultado =null; paso otros datos de esta forma
   
            $router -> render('inscripcion/admin', [
                    'alumnos' => $alumnos  ]);
    }


    public static function nuevo(Router $router){
        if (isset($_GET['id'])) { 
            $id =$_GET['id'];  
            $id = filter_var($id, FILTER_VALIDATE_INT);
             if (!$id) {
            header("Location: /admin");
                 }
                // Instancia Cursos para tomar datos
            $curso = Cursos::find($id);
        } else {
                    // En caso de errores tomo el id como retorno
            $id = $_POST['inscripcion']['fk_curso'];
            $curso = Cursos::find($id);
          
        }

        $inscripcion = new Inscripcion();
        $errores = Inscripcion::getErrores();
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // creo instancia con lo que viene del post
            $inscripcion = new Inscripcion($_POST['inscripcion']);
            //validacion   
            $errores = $inscripcion->validar();     
            // El array de errores esta vacio
         if (empty($errores)) {
    
            $inscripcion->crear();
            // codigo para ejecutar CRUD
        }
        }
       
        $router -> render('inscripcion/nuevo', [
            'curso' => $curso,
            'inscripcion' => $inscripcion,
            'errores' => $errores,
            'id' => $id
        
        ]);


        
    }
        
     public static function actualizar(Router $router){
       
                 $id =  $_GET['id'];
		         $id = filter_var($id, FILTER_VALIDATE_INT);
		        if (!$id) {
			                    header("Location: /admin");
		               }
             $alumno = Inscripcion::find($id);          
             $errores = Inscripcion::getErrores();

             if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                $args = $_POST['alumno'];
    
                $alumno->sincronizar($args);
             
                //validacion
                $errores = $alumno->validar();
          
                // El array de errores esta vacio
			if (empty($errores)) {
            
                $alumno->guardar();
			}
           
        }
                 $router -> render('inscripcion/actualizar',
                 [
                    'alumno' => $alumno,
                    'errores' => $errores

                 ]);
         
                
    }
       public static function eliminar(Router $router){

             $id = $_GET['id'];
             	// Sanitizar número entero
			 $id = filter_var($id, FILTER_SANITIZE_NUMBER_INT);
             if (!$id) {
                header("Location: /admin");
       }
			// Eliminar... 
			if ($id) {      
					$alumno= Inscripcion::find($id);
                } 

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $alumno->eliminar();
        }
			
	
            $router -> render('inscripcion/eliminar', [
               
                'alumno' => $alumno,
            ]);
       
       }


}