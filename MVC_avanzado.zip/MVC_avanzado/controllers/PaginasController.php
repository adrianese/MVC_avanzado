<?php

namespace Controllers;

use MVC\Router;
use Model\Inscripcion;
use Model\Cursos;
use PHPMailer\PHPMailer\PHPMailer;


class PaginasController {

    public static function index(Router $router){
        $cursos = Cursos::all() ;
        $inicio = true;
  
        $router -> render('paginas/index', [
            'cursos' => $cursos,
            'inicio' => $inicio    ]);

    }



    public static function contacto(Router $router){
            $mensaje = null;

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $nombre = $_POST['nombre'];
            $correo = $_POST['correo'];
            $cuerpo = $_POST['mensaje'];
   

            /// Crear objeto para enviar mails
            $mail = new PHPMailer(true);
             //$mail = new PHPMailer();
            // Configurar SMTP
             $mail->isSMTP();
            $mail->Host = 'xx.smtp.mailtrap.xx';    // colocar credenciales de mailtrap
            $mail->SMTPAuth = true;                      // colocar credenciales de mailtrap
            $mail->Username = 'xxxxxxxx';          // colocar credenciales de mailtrap
            $mail->Password = 'xxxxxxx';          // colocar credenciales de mailtrap
            $mail->SMTPSecure ='tls';                    // colocar credenciales de mailtrap
            $mail->Port = 2525;                          // colocar credenciales de mailtrap

            //Configurar el contenido del email
            $mail -> setFrom('admin@xxxx.com');          // colocar tus credenciales 
            $mail -> addAddress('admin@xxxxx.com', '');  // colocar tus credenciales 
            $mail -> Subject = 'Tienes un nuevo mensaje';

                // Habilitar HTML
            $mail->isHTML(true);
            $mail->CharSet = 'UTF-8';


            //Definir Contenido
            $contenido = '<html>';         
            $contenido .= '<p>Tienes un nuevo mensaje </p>';
            $contenido .='<p>Nombre:' . $nombre. '</p>';
            $contenido .='<p>Correo:' . $correo. '</p>'; 
            $contenido .='<p>Mensaje:' . $cuerpo. '</p>';
            $contenido .= '</html>';


            $mail->Body = $contenido;
            $mail->AltBody = 'Esto es texto Alternativo';

            if ($mail->send()) {
                //retorna true o false si se envió
            $mensaje = "Mensaje enviado correctamente";
                 }else{ $mensaje = "El mensaje no se pudo enviar";}



    

    }
        

    $router ->render('paginas/contacto', [
        'mensaje' => $mensaje
        ]);


    }



public static function nosotros(Router $router){
    echo "desde nosotros";

    $router -> render('paginas/nosotros', []);

    // si la pag es estatica no se pasan valores
    
}

public static function cursos(Router $router){
    echo "desde cursos";
    
}


}

