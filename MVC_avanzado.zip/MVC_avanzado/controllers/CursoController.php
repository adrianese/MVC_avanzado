<?php

namespace Controllers;

use MVC\Router;
use Model\Cursos;
use Model\Profesores;
use Intervention\Image\ImageManagerStatic as Image;






class CursoController {

        public static function todos(Router $router){
            
               $curso = Cursos::all();
           
            $router ->render('curso/todos', [
                    'curso' => $curso     ]);
              // en el view el action debe ser el cursos/nuevo sin php 

        }

               
        public static function nuevo(Router $router){
                $curso = new Cursos();         
                  //traer errores
                $errores = Cursos::getErrores();
            
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {               
                //Crea nueva instancia
                $curso = new Cursos($_POST['curso']) ;

                 //validacion
                $errores = $curso->validar();
               
			//genera un nombre unico para la imagen
			$nombreImagen = md5(uniqid(rand(), true)) . ".jpg";

			// El array de errores esta vacio
			if (empty($errores)) {
                 
			if ($_FILES) {
                  //resize imagen 
				$image = Image::make($_FILES['curso']['tmp_name']['imagen'])->fit(200, 200);
                 //seteo nombre imagen
				$curso->setImagen($nombreImagen);
				//guarda imagen en servidor 
				$image->save(CARPETA_IMAGENES . $nombreImagen);
			}       
				// Insertar en la BD.
				$curso->guardar();
			}		
        }
            $router ->render('curso/nuevo', [
                'curso' => $curso,
                'errores' => $errores ]);
            
        }

        
        public static function actualizar(Router $router){
            $id =  $_GET['id'];
            $id = filter_var($id, FILTER_VALIDATE_INT);
            if (!$id) {
                header("Location: /admin");
            }

            $curso = Cursos::find($id);
            $profesor = Profesores::all();
            $errores = Cursos::getErrores();

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                $args = $_POST['curso'];
    
                $curso->sincronizar($args);
             
                //validacion
                $errores = $curso->validar();

            	// El array de errores esta vacio
			if (empty($errores)) {

            //genera un nombre unico
			$nombreImagen = md5(uniqid(rand(), true)) . ".jpg";

			if ($_FILES['curso']['tmp_name']['imagen']) {
				$image = Image::make($_FILES['curso']['tmp_name']['imagen'])->fit(200, 200);
                // Guarda el nombre en el arreglo
				$curso->setImagen($nombreImagen);
	                //Subir la imagen
                	$image->save(CARPETA_IMAGENES . $nombreImagen);
			}
				// Insertar en la BD.           				
                $curso->guardar();
			}          
        }
                 $router ->render('curso/actualizar', [
                'curso' => $curso,
                'errores' => $errores,  
                'profesor'  => $profesor  ]);
            
        }



        public static function eliminar(Router $router){

            $id =  $_GET['id'];
            $id = filter_var($id, FILTER_VALIDATE_INT);
            if (!$id) {
                header("Location: /admin");
            }

                $curso = Cursos:: find($id);
                $curso -> eliminar();
          // no se necesita para eliminar
          //  $router ->render('cursos/eliminar', [.... ]);
            
          $router ->render('curso/todos?msj=3',);
        }


    






}