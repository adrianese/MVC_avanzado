<?php

require_once '../includes/app.php';

use MVC\Router;
use Controllers\InscripcionController;
use Controllers\CursoController;
use Controllers\PaginasController;
use Controllers\AdminController;

$router = new Router();

// Zona privada
$router-> get('/admin', [InscripcionController::class,'index']);
$router-> get('/inscripcion/nuevo', [InscripcionController::class,'nuevo']);
$router-> get('/inscripcion/actualizar', [InscripcionController::class,'actualizar']);
$router-> get('/inscripcion/eliminar', [InscripcionController::class,'eliminar']);
$router-> post('/inscripcion/nuevo', [InscripcionController::class,'nuevo']);
$router-> post('/inscripcion/actualizar', [InscripcionController::class,'actualizar']);
$router-> post('/inscripcion/eliminar', [InscripcionController::class,'eliminar']);


$router-> get('/curso/todos', [CursoController::class,'todos']);
$router-> get('/curso/actualizar', [CursoController::class,'actualizar']);
$router-> get('/curso/nuevo', [CursoController::class,'nuevo']);
$router-> post('/curso/nuevo', [CursoController::class,'nuevo']);
$router-> post('/curso/actualizar', [CursoController::class,'actualizar']);
$router-> get('/curso/eliminar', [CursoController::class,'eliminar']);

// Zona Publica

$router-> get('/', [PaginasController::class,'index']);
$router-> get('/contacto', [PaginasController::class,'contacto']);
$router-> post('/contacto', [PaginasController::class,'contacto']);
//$router-> get('/nosotros', [PaginasController::class,'nosotros']);
//$router-> get('/cursos', [PaginasController::class,'cursos']);


$router->get('/auth/login', [AdminController::class, 'login']);
$router->post('/auth/login', [AdminController::class, 'login']);
$router->get('/auth/logout', [AdminController::class, 'logout']);



$router -> comprobarRutas();




