<?php



require 'funciones.php';
require 'config/database.php';
require_once './../vendor/autoload.php';

use Model\Base;
// Conectarnos a la base de datos
$db = conectarDB();

Base::setDB($db);