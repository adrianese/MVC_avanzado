<?php 

function conectarDB() : mysqli {
    $db = new mysqli('localhost', 'root', '', '');
    // Setear con los valores correspondientes

    if(!$db) {
        echo "Error no se pudo conectar";
        exit;
    } 

    return $db;
    
}