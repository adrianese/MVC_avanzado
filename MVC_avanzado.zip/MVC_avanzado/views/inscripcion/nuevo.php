

<h2>Formulario de Inscripción</h2>
<div class=" row contenedor inscripcion">
  <div>
    <?php foreach ($errores as $error) : ?>
      <div class="alerta error">
        <?php echo $error; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <div class=" col-md-3 col-lg-3 col-xl-3 ">
    <h2> Tu Selección: </h2>


    <div class="tu_seleccion">
      <h3> <?php echo $curso->nombre; ?> </h3>
      <img width=100px src="../imagenes/<?php echo $curso->imagen; ?> ">
    </div>

  </div>

  <div class=" container col-md-6 col-lg-6 col-xl-6 ">
    <form class="formulario" action="/inscripcion/nuevo" method="POST" enctype="multipart/form-data">
      <fieldset>

        <input type="hidden" name="inscripcion[fk_curso]" value=" <?php echo $curso->id; ?>">
        <div class="contenedor-campos">

          <div class="contenedor-campos mb-1">
            <label for="nombre" class="form-label"></label>
            <input type="text" class="input-text" name="inscripcion[nombre]" value="<?php echo $inscripcion->nombre; ?>" placeholder="Nombre">
          </div>
          <div class=" contenedor-campos mb-1">
            <label for="apellido" class="form-label"></label>
            <input type="text" class="input-text" id="apellido" name="inscripcion[apellido]" value="<?php echo $inscripcion->apellido; ?>" placeholder="Apellido">
          </div>
          <div class="contenedor-campos mb-1">
            <label for="edad" class="form-label"></label>
            <input type="number" class=" input-text" name="inscripcion[edad]" value="<?php echo $inscripcion->edad; ?>" placeholder="Edad"></input>

          </div>
          <div class="contenedor-campos mb-1">
            <label for="correo" class="form-label"></label>
            <input type="email" class=" input-text" id="correo" value="<?php echo $inscripcion->correo; ?>" name="inscripcion[correo]" placeholder="Correo"></input>
          </div>

          <div class="contenedor-campos mb-2">
            <label> ¿Quieres recibir informacion sobre los nuevos cursos?</label>
            <div> <input type="radio" name="inscripcion[info]" value="si">Si</div>
            <div> <input type="radio" name="inscripcion[info]" value="no">No</div>
          </div>
          <legend>


          </legend>


          <div class="contenedor-campos d-grid gap-1">
            <button type="submit" class="boton boton-grande" name="guardar">Aplicar</button>
            <br>
            <button class=" boton boton-grande " type="reset" name="limpiar ">Limpiar</button>
          </div>
        </div>

      </fieldset>
    </form>
    <div class=" col-md-3 col-lg-3 col-xl-3 "> </div>
  </div>
</div>
</div>