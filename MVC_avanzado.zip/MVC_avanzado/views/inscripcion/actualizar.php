

<h2> // Editar Registro // </h2>


<div class="row">
  

        <div class="col-md-4 col-lg-4 col-xl-4">
        </div>
        <div class=" col-md-4 col-lg-4 col-xl-4 ">

        <?php foreach ($errores as $error) : ?>
        <div class="alerta error">
            <?php echo $error; ?>
        </div>
    <?php endforeach; ?>


            <form class="formulario" action="" method="POST">
  
            <div class=" contenedor-campos mb-2">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" class="input-text" name="alumno[nombre]"  value="<?php echo s($alumno->nombre);?>" >
              </div>
              <div class="contenedor-campos mb-2">
                <label for="apellido" class="form-label">Apellido</label>
                <input type="text" class="input-text " name="alumno[apellido]" value="<?php echo s($alumno->apellido);?>" >
              </div>

              <div class="contenedor-campos mb-2">
                <label for="edad" class="form-label">Edad</label>
                <input type="text" class="input-text" name="alumno[edad]" value="<?php echo s($alumno->edad);?>" >

              </div>
               
              <div class="contenedor-campos mb-2" >
                <label for="correo" class="form-label">Correo</label>
                <input class="input-text " type=email name="alumno[correo]" value="<?php echo s($alumno->correo);?> " 
                 name="correo">
              </div>

                 <div class="contenedor-campos mb-2 py-2 ">
                    <label> Informacion sobre los nuevos cursos?</label>
                    <div> <input  type="radio" name="alumno[info]" value="si" <?php echo (s($alumno->info)=="si")?"checked":""; ?> >Si </div>
                    <div> <input  type="radio" name="alumno[info]" value="no" <?php echo (s($alumno->info=="no"))?"checked":""; ?> >No </div>

                    <input type="hidden" name="id" value="<?php echo s($alumno->id)?>">

                 
                    </div>

              <div class="d-grid gap-2 py-3">
                <button class="boton btn btn-success" type="submit"  name="editar" >Editar Datos</button>
              </div>
              <div class="d-grid gap-2 py-3">
            
                <a class="boton btn btn-info" name= "cancelar"  href="/admin?msj=0">Cancelar</a>
              </div>

             </form>
        </div>
        <div class=" col-md-4 col-lg-4 col-xl-4">
        </div>
      
</div>
</div>
