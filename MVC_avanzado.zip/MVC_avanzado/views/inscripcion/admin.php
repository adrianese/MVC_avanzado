<?php
include_once '../includes/app.php';


if (isset ($_SESSION['welcome'])) {
    echo "<h2 style = 'color: green;'> Bienvenido " . $_SESSION['usuario'] . "!! </h2>";
    $_SESSION['welcome']= NULL;
 }
?>   
         <h2>Administrador de Alumnos</h2>
    
        
         
            <div class=" row contenedor">
            <?php 
            $msj=$_GET['msj'] ?? null;
         
         if ($msj) {
           // Gestion de alertas
           $mensaje = mostrarNotificacion(intval($msj));
           if ($mensaje) { ?>
               <p class="alerta exito"><?php echo s($mensaje)?></p>
         
         <?php } 
           
        }
        ?>
                 
                    <div class=" ">
                        <table class="table table-striped" > 
                            <thead>
                                <tr>
            
                                    <th>#</th>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th>Correo</th>
                                    <th>Edad</th>
                                    <th>Info</th>
                                    <th>Curso</th>
                                    <th>Fecha</th>
                                    <th>Editar | Borrar</th>
                                </tr>
            
                            </thead>
                            <tbody>

                            <?php
                    
                                   foreach ($alumnos as $row) : ?>

                                <tr>
                                <td> <?php echo $row->id ?>  </td>
                            <td> <?php echo $row->nombre ?>  </td>
                            <td> <?php echo $row->apellido ?>  </td>
                            <td> <?php echo $row->correo?>  </td>
                            <td> <?php echo $row->edad ?>  </td>
                            <td> <?php echo $row->info ?>  </td>
                            <td> <?php echo $row->fk_curso?>  </td>
                            <td> <?php echo $row->fecha ?>  </td>

                            <td>
                                <a href="inscripcion/actualizar?id=<?php echo$row->id;?>" >Editar</a>

                                <a href="inscripcion/eliminar?id=<?php echo$row->id;?>" >Borrar</a>
                            </td>
                    </tr>
                <?php  endforeach ?>
            </tbody>            
                        </table>   
                    </div>                     
            </div>
    