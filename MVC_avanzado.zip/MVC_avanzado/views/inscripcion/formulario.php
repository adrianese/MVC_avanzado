
<div class=" contenedor-campos mb-2">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" class="input-text" name="alumno[nombre]"  value=" <?php echo s($alumno->nombre); ?>" >
              </div>
              <div class="contenedor-campos mb-2">
                <label for="apellido" class="form-label">Apellido</label>
                <input type="text" class="input-text " name="alumno[apellido]" value=" <?php echo s($alumno->apellido); ?>"  >
              </div>

              <div class="contenedor-campos mb-2">
                <label for="edad" class="form-label">Edad</label>
                <input type="text" class="input-text" name="alumno[edad]"  value=" <?php echo s($alumno->edad); ?> " >

              </div>
               
              <div class="contenedor-campos mb-2" >
                <label for="correo" class="form-label">Correo</label>
                <input class="input-text " type=email name="alumno[correo]" value=" <?php echo s($alumno->correo); ?> " 
                 name="correo">
              </div>

                 <div class="contenedor-campos mb-2 py-2 ">
                    <label> Informacion sobre los nuevos cursos?</label>
                    <div> <input  type="radio" name="info" value="si" <?php echo (s($alumno->info)=="si")?"checked":""; ?> >Si </div>
                    <div> <input  type="radio" name="info" value="no" <?php echo (s($alumno->info=="no"))?"checked":""; ?> >No </div>

                    <input type="hidden" name="id" value="<?php echo s($alumno->id)?>">

                 
                    </div>