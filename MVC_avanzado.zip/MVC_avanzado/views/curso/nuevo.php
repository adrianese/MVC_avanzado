
<main class="contenedor sombra ">
            <div class="container">
            <div class=" campo contenedor-campos sombra">
                    <img src="" alt="" srcset="">
                    <h2>Cargar Curso Nuevo</h2>
                    
                    <div>
                     <?php foreach ($errores as $error) : ?>
                    <div class="alerta error">
                      <?php echo $error; ?>
                    </div>
                     <?php endforeach; ?>
                    </div>

                    <form  class="formulario" action="/curso/nuevo" method="POST" enctype="multipart/form-data" >
                <input type="text" placeholder ="Nombre del Curso" class=" campo input-text" value="<?php echo $curso->nombre ;?>" name="curso[nombre]">
                <textarea name="curso[descripcion]" class="campo input-text" id="" cols="30" placeholder ="Descripción" rows="10"><?php echo $curso->descripcion;?></textarea>
         
                <input type="text" placeholder ="Precio" class=" campo input-text" value="<?php echo $curso->precio ;?>" name="curso[precio]">                
                <input type="number" placeholder ="Cupo" class=" campo input-text" value="<?php echo $curso->cupo ;?>" name="curso[cupo]">
                <input type="number" name="curso[fk_profesor]" class=" campo input-text" value="<?php echo $curso->fk_profesor ;?>" placeholder= "Profesor 1 o 2">
                <input type="file" name="curso[imagen]" class=" boton " accept="image/jpeg"  placeholder= "">
                <p>Cargar imagen JPG</p>
                <input type="submit" class="boton" class="campo input-text"  name="cargar" value="Cargar Curso">
                
                </form>
    </div>
     <div class="sombra">

    
     </div>
    
        </div>