
<main class="contenedor sombra ">
    <div class="container">
         <div class=" campo contenedor-campos sombra">
                
                    <h2>Editar Curso</h2>
                    <div>
    <?php foreach ($errores as $error) : ?>
      <div class="alerta error">
        <?php echo $error; ?>
      </div>
    <?php endforeach; ?>
  </div>

     <form  class="formulario" action="" method="POST" enctype="multipart/form-data" >
     <fieldset>
            <legend>Nombre del Curso y Descripción:</legend>
                <input type="text" placeholder ="Nombre del Curso" class=" campo input-text" value="<?php echo s($curso->nombre); ?> " name="curso[nombre]">
                <textarea name="curso[descripcion]" class="campo input-text" id="" cols="30" placeholder ="Descripción" rows="10"> <?php echo s($curso->descripcion); ?> "</textarea>
      </fieldset>
               
                <fieldset>
            <legend>Precio y Cupo:</legend>
                <input type="text" placeholder ="Precio" class=" campo input-text" value="<?php echo s($curso->precio); ?> " name="curso[precio]">                
                <input type="number" placeholder ="Cupo" class=" campo input-text" value="<?php echo s($curso->cupo);?>" name="curso[cupo]">
       </fieldset>
       <fieldset>
            <legend>ID Profesor(a):</legend>
                <input type="number" name="curso[fk_profesor]" class=" campo input-text" value="<?php echo s($curso->fk_profesor);?>" placeholder= "Profesor 1 o 2">
                <fieldset>  
                <img src="/imagenes/<?php echo $curso->imagen ;?>" alt="IMG" width="100" srcset="">
                <input type="file" name="curso[imagen]" class=" boton " accept="image/jpeg"  placeholder= "Imagen">
                <p>Cargar imagen JPG</p>
                <input type="submit" class="boton" class="campo input-text"  name="cargar" value="Cargar Curso">
              
            
          
        
                
                </form>
    </div>
     <div class="sombra"> </div>