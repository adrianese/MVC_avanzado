
<section>

<h2>Administrador de Cursos</h2>   
                          
            <div class=" contenedor">
            <div> <a class="boton boton-contacto" href="/curso/nuevo ">Cargar Nuevo Curso</a></div>
                    <div class=" ">
                        <table class="table table-striped" > 
                        <thead>
                                 <tr>
                                    <th>#</th>
                                    <th>Curso</th>
                                    <th>Descripción</th>
                                    <th>Costo</th>
                                    <th>Cupos</th>
                                    <th>profesor</th>
                                    <th> |  </th>
                                </tr> 
                        </thead>                                               
                            <tbody>                        
                            <?php
                          
                         foreach ($curso as $row) : ?>

                              
                        <tr> <td> <?php echo $row->id ?>  </td>
                            <td> <?php echo $row->nombre ?>  </td>
                            <td> <?php echo $row->descripcion ?>  </td>
                            <td> <?php echo $row->precio ?>  </td>
                            <td> <?php echo $row->cupo ?>  </td>                          
                            <td> <?php echo $row->fk_profesor ?>  </td>                           
                            <td>
                                <a href="/curso/actualizar?id=<?php echo $row->id;?>" >Editar</a> 
                                <a href="/curso/eliminar?id=<?php echo $row->id;?>" >Borrar</a> 
                            </td>
                         </tr>

                <?php  endforeach ?>
            </tbody>


            
                        </table>   
                    </div>
                   
        
    </div>
    </section>