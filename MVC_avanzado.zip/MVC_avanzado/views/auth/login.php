<?php

    ?>

    <main class="contenedor sombra ">

    <div class="container">
                <div>
                <?php foreach ($errores as $error) : ?>
                 <div class="alerta error">
                 <?php echo $error; ?>
                </div>
                 <?php endforeach; ?>
                 </div>
    <div class=" campo contenedor-campos sombra">
                    <img src="" alt="" srcset="">
                    <h2>Iniciar Sesion</h2>
                    <form  class="formulario" action="" method="POST">

                <input type="text" name="usuario" class=" campo input-text" placeholder ="Usuario"   >
                <input type="text" name="clave" class=" campo input-text"  placeholder= "Clave">
                <input type="submit" class="boton" class="campo input-text"  name="ingreso" value="ingreso">
                </form>
           </div>
    
       
            </div>
      
    </main>
