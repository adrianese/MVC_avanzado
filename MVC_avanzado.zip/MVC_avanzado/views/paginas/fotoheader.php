<section class="imagen">
        <div class="contenido-imagen">
            <h1>Nuestros Cursos Online y Gratuitos </h1> 
            <h1> Anotate!</h1>
        
            <a class="boton boton-contacto" href="#contacto">Contactar</a>
        </div> <!-- .contenido-imagen --> 
    </section>