


    <main class="contenedor sombra ">

         <div class="container">
            <div class=" campo contenedor-campos sombra">
                    <img src="" alt="" srcset="">
                    <?php       if($mensaje) { ?>
                        <p class= "alerta exito"> <?php echo $mensaje ; ?> </p>;
                    <?php  }  ?>
               
           </div>
           <div class="sombra"> </div>
    
    </div>    
    </main>