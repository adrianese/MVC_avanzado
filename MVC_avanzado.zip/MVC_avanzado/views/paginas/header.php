<?php
$inicio = true;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academia de Cursos</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Krub:wght@400;700&display=swap" rel="stylesheet">
    <link rel="preload" href="../css/styles.css" as="style">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   
    <link href="../css/styles.css" rel="stylesheet">
</head>
<body>
<div class="nav-bg">|</div>
    <header>
        <h2 class="titulo">Curso de PHP y MySQL Avanzado <span>#999191538</span></h2>
    </header>

    <div class="nav-bg">
        <nav class="navegacion-principal contenedor">
            <a href="/">Inicio</a>
            <a href="#cursos">Cursos</a>
            <a href="#contacto">Contacto</a>
            <a href="#"></a>
            <a href="#"></a>
            <a href="/auth/login">Admin</a> 
           
        </nav>
    </div>
    