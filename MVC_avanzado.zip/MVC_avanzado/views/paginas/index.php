<?php
   
    include("fotoheader.php");

?>
    
    <main class="contenedor sombra ">
    <h2 id="cursos" >Nuestros Cursos </h2>      
        <div  class="cursos">
        <?php foreach ( $cursos as $curso ) : 
            $id = $curso->id;
        ?>

            <section class="curso">
                <div class="curso_titulo">
                <h3><?php echo $curso->nombre ?></h3>
                <div class="iconos">
                <img height="200 px" src="imagenes/<?php echo  $curso->imagen; ?>" alt="LOGO">
                </div>
                </div>
                <div class="descripcion">
                <p> Descripción del curso: <?php echo $curso->descripcion ?></p>
              
                <div class="precio-inscripcion">
                    <div class="precio boton">
                        <h3>precio $  <?php echo $curso->precio ?></h3>

                    </div>
                    <div class="inscripcion  precio ">
                    <a href="inscripcion/nuevo?id=<?php echo $curso->id ;?> " ><h2>Inscribite ahora!</h2></a>
                    </div>
               </div>           
                </div>               
            </section>              
        </div> <!--cursos-->
        <?php  endforeach ?>
        <section>            
            <h2 id="contacto">Contacto </h2>           
            <form method="POST" action="/contacto" class="formulario">
           
                <fieldset>
                    <legend>Contactános llenando todos los campos</legend>
                    <div class="contenedor-campos">
                        <div class="campo">
                            <label>Nombre</label>
                            <input class="input-text" name="nombre" type="text" required placeholder="Tu Nombre">
                        </div>                        
                        <div class="campo">
                            <label>Correo</label>
                            <input class="input-text" name="correo" type="email"required placeholder="Tu Email">
                        </div>               
                        <div class="campo">
                            <label>Mensaje</label>
                            <textarea class="input-text" required name="mensaje"></textarea>
                        </div>
                    </div> <!---campos form-->
                    <div class="alinear-derecha flex">
                        <input class="boton boton_grande" type="submit" name="contacto" value="enviar">
                    </div>
                   
                </fieldset>
            </form>
        </section>

    </main>
