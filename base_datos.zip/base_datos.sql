-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_curso
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administracion`
--

DROP TABLE IF EXISTS `administracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `clave` char(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administracion`
--

LOCK TABLES `administracion` WRITE;
/*!40000 ALTER TABLE `administracion` DISABLE KEYS */;
INSERT INTO `administracion` VALUES (1,'',''),(2,'admin','$2y$10$Su0WULzdHED.bYRPWctfauQzIgQhDi9WTuzHntx1JVS2VBF4PDjCC');
/*!40000 ALTER TABLE `administracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cursos`
--

DROP TABLE IF EXISTS `cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cursos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` varchar(10) NOT NULL,
  `imagen` varchar(40) NOT NULL,
  `cupo` int NOT NULL,
  `fk_profesor` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_profesor` (`fk_profesor`),
  CONSTRAINT `cursos_ibfk_1` FOREIGN KEY (`fk_profesor`) REFERENCES `profesores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cursos`
--

LOCK TABLES `cursos` WRITE;
/*!40000 ALTER TABLE `cursos` DISABLE KEYS */;
INSERT INTO `cursos` VALUES (1,'Curso de HTML y CSS   ','   Conoce todo sobre etiquetas HTML y CSS, como dar estilo a los elementos de tu sitio web. Aprende a construir sitios para internet de manera eficiente. Aplicar estilos usando CSS3. Dominar la anatomía de un elemento HTML. Crear Sitios Web estáticos con HTML y CSS3 \" \" \"','sin cargo','ac5ad4b8855ca6586e90cf4334894894.jpg',10,1),(2,'Curso de PHP y MySQL','Aprende PHP, el lenguaje de programación para backend presente en el 80% de sitios web. Inicia tu ruta de aprendizaje como PHP Developer y desarrolla tus primeros algoritmos. Configura tu entorno de desarrollo con herramientas como \"XAMPP\"','sin cargo','d5fecdfbe9974e984a766bf7001aebcb.jpg',15,2),(4,'Curso de Javascript  ','  Conocer los conceptos básicos de JS.\r\nDescubrir la historia de JavaScript.\r\nAprender cómo tomar decisiones y validarlas Trabajar con objetos. \" \"','sin cargo ','a2831a84214a489262a35343329227f5.jpg',12,1),(5,' Actualizacion SASS desde MVC','   Las hojas de estilo CSS, cada vez son más complejas y extensas. Esto conlleva que el mantenimiento de los estilos en un proyecto de gran envergadura, sea cada vez más tedioso. La gran cualidad de SASS es que te permite llevar tu CSS un paso más adelante, permite reutilizar código, \r\norganizar las clases y permite trabajar mucho más rápido. \" \" \"','7400   ','e64c2da35ebeb79a4d8922890f551984.jpg',15,1),(6,'Uso de Gulp ',' Es una herramienta, en forma de script en NodeJS, que te ayuda a automatizar tareas comunes en el desarrollo de una aplicación, como pueden ser: mover archivos de una carpeta a otra, \r\neliminarlos, minificar código, sincronizar el navegador cuando modificas tu código.\r\n\r\n \"','6900 ','9f3f34a3aa3dcbcc25ffea6817d8d777.jpg',10,2),(7,'Todo sobre Node ',' Node.js es un entorno en tiempo de ejecución multiplataforma, de código abierto, para la capa del \r\nservidor (pero no limitándose a ello) basado en el lenguaje de programación JavaScript, asíncrono, orientada a eventos y basado en el motor V8 de Google. \r\nFue creado con el enfoque de ser útil en la creación de programas de red altamente escalables, como por ejemplo, servidores web.\r\n\r\n \"','7400 ','116819c7bf3d1b8c37eebf3da1f4b7b0.jpg',12,2),(9,' Curso de Astronomia con MVC','   La astronomía es la ciencia que se ocupa del estudio de los cuerpos celestes del universo, incluidos los planetas y sus satélites, los cometas y meteoroides, las estrellas y la materia interestelar, los sistemas de materia oscura, gas y polvo llamados galaxias y los cúmulos de galaxias; por lo que estudia sus movimientos y los fenómenos ligados a ellos. Su registro y la investigación de su origen viene a partir de la información que llega de ellos a través de la radiación  \" \"','sin cargo ','67d586ab59c7d46d16398219c97dbcaa.jpg',6,1),(15,' Desarrollo Web','Conoce los conceptos clave del lenguaje de programación que se está comiendo al mundo. Aprende qué es una variable, una función, un objeto y dónde se guardan esos valores. Descubre qué es Scope y cómo se utilizan los loops. Obtén las herramientas para saber cómo tomar decisiones y validar acciones. En este curso, darás el primer paso para empezar tu carrera como desarrollador. Conocer los conceptos básicos de JS Aprender cómo tomar decisiones y validarlas\r\nTrabajar con objetos','9500','e90177d1c8643528fca166010ff845e1.jpg',12,1),(16,'Curso de Huerta ','    Este curso te capacita a para producir tus propios vegetales orgánicos, ricos en nutrientes y\r\ncon innumerables beneficios para la salud propia y de la comunidad. Podrás implementar técnicas de\r\nproducción de alimentos orgánicos, despertando la creatividad en la combinación de ingredientes y\r\nhaciendo de su cocina un lugar saludable y nutritivo. \r\nSalida laboral\r\nLa demanda de alimentos orgánicos, sin agrotóxicos, crece cada año, producción y venta de platines o productos derivados de los mismos. El egresado podrá desempeñarse en viveros propios o ajenos y\r\ncolaborar en los mismos. \" \" \" \"','sin cargo','dfa27d9ae20464a8d02c7a156bdec843.jpg',12,1);
/*!40000 ALTER TABLE `cursos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscripcion`
--

DROP TABLE IF EXISTS `inscripcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscripcion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `apellido` varchar(40) NOT NULL,
  `correo` varchar(40) NOT NULL,
  `edad` int NOT NULL,
  `info` varchar(3) NOT NULL,
  `fecha` date NOT NULL,
  `fk_curso` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_curso` (`fk_curso`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscripcion`
--

LOCK TABLES `inscripcion` WRITE;
/*!40000 ALTER TABLE `inscripcion` DISABLE KEYS */;
INSERT INTO `inscripcion` VALUES (4,'Andrés','Sancho','sanchoval@hotmail.com',29,'no','2022-11-03',2),(13,'Maria','Juana  ','juma@micorreo.com',32,'no','2022-11-04',1),(16,'Pepo','Rodriguez','pe_ro@gmail.com',31,'si','2022-11-08',4),(18,' Juana',' Juan','juju@micorreo.com',35,'si','2022-11-11',4),(20,'  Luis',' Jorge','lu_jo@correo.com',42,'si','2022-11-11',6),(24,'Pepa','Pig','pe_pig@mimail.com',32,'si','2023-07-12',1),(25,'  Pedro','  Pablo','pe_pa@tucorreo.com',45,'no','2023-08-23',4),(28,' Mario','Bros','mario@gmail.com',45,'si','2023-08-25',2),(29,' Paco ','Tiyo','pacotillo@micorreo.com',43,'si','2023-08-25',2),(30,' Mara','Mari','mama@correo.com',33,'no','2023-08-26',1),(32,'Dama','Juana  ','correo@correo.com',41,'si','2023-08-26',7);
/*!40000 ALTER TABLE `inscripcion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profesores`
--

DROP TABLE IF EXISTS `profesores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profesores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `apellido` varchar(40) NOT NULL,
  `curso` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profesores`
--

LOCK TABLES `profesores` WRITE;
/*!40000 ALTER TABLE `profesores` DISABLE KEYS */;
INSERT INTO `profesores` VALUES (1,'Profesor José','Castro','HTML y CSS'),(2,'Profesora Analía','Del Campo','PHP y MySQL ');
/*!40000 ALTER TABLE `profesores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-26 12:37:09
